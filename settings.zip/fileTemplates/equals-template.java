#parse("equalsHelper.vm")
   public boolean equals(##
   #if ($settings.generateFinalParameters)
   final ##
   #end
   Object $paramName){
   #addEqualsPrologue()
   #addClassInstance()
   return ##
   #set($i = 0)
   #foreach($field in $fields)
       #if ($i > 0)
       &&##
       #end
       #set($i = $i + 1)
       #if ($field.primitive)
           #if ($field.double || $field.float)
               #if ($foreach.hasNext)
                   #addDoubleFieldComparisonConditionDirect($field)
               #else
                   #addDoubleFieldComparisonConditionDirect($field)##
               #end
           #else
               #if ($foreach.hasNext)
                   #addPrimitiveFieldComparisonConditionDirect($field)
               #else
                   #addPrimitiveFieldComparisonConditionDirect($field)##
               #end
           #end
       #elseif ($field.enum)
           #if ($foreach.hasNext)
               #addPrimitiveFieldComparisonConditionDirect($field)
           #else
               #addPrimitiveFieldComparisonConditionDirect($field)##
           #end
       #elseif ($field.array)
           #if ($foreach.hasNext)
           java.util.Arrays.equals($field.accessor, ${classInstanceName}.$field.accessor)
           #else
           java.util.Arrays.equals($field.accessor, ${classInstanceName}.$field.accessor)##
           #end
       #elseif ($field.notNull)
           #if ($foreach.hasNext)
               ${field.accessor}.equals(${classInstanceName}.$field.accessor)
           #else
               ${field.accessor}.equals(${classInstanceName}.$field.accessor)##
           #end
       #else
           #if ($foreach.hasNext)
               java.util.Objects.equals($field.accessor, ${classInstanceName}.$field.accessor)
           #else
               java.util.Objects.equals($field.accessor, ${classInstanceName}.$field.accessor)##
           #end
       #end
   #end
   ;
   }